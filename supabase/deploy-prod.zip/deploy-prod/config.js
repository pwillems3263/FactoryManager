// ─────────────────────────────────────────────────────────────────────────────
// config.js — PRODUCTION
// ─────────────────────────────────────────────────────────────────────────────
// Copy this file alongside index.html when deploying.
// Never commit the service_role key here — only the anon (public) key.
// ─────────────────────────────────────────────────────────────────────────────

const SUPABASE_URL  = "https://ujgpqzuuxigkketbmuyd.supabase.co";
const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqZ3BxenV1eGlna2tldGJtdXlkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg0MjI2MTcsImV4cCI6MjA5Mzk5ODYxN30.VKwxTwghbx31m6LB7ABckwlXyy2gBbyMlyQbw0chlCA";
const TIMEOUT_SEC   = 120;  // auto-logout after 2 minutes inactivity
