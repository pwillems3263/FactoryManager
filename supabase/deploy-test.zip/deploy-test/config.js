// ─────────────────────────────────────────────────────────────────────────────
// config.js — TEST
// ─────────────────────────────────────────────────────────────────────────────

const SUPABASE_URL  = "https://lpacfgyhhvdfuzvlfmul.supabase.co";
const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxwYWNmZ3loaHZkZnV6dmxmbXVsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgxNjY2NzYsImV4cCI6MjA5Mzc0MjY3Nn0.SFcJ0LXab9kkcTHRSrx3tfRM9kaw8Ti8GIK-dbd5MBs";
const TIMEOUT_SEC   = 120;
